<!-- resources/views/bukus/index.blade.php -->
@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Daftar Buku</h1>
        <a href="{{ route('bukus.create') }}" class="btn btn-primary mb-3">Tambah Buku</a>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        <!-- Pencarian Form -->
        <form method="GET" action="{{ route('bukus.index') }}" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari..."
                    value="{{ request()->input('search') }}">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </form>


        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal Masuk</th>
                    <th>Nama Buku</th>
                    <th>Kelas</th>
                    <th>Jenis</th>
                    <th>Stok</th>
                    <th>Harga</th>
                    <th>Tautan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($bukus as $buku)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $buku->tanggal_masuk }}</td>
                        <td>{{ $buku->nama_buku }}</td>
                        <td>{{ $buku->kelas }}</td>
                        <td>{{ $buku->jenis }}</td>
                        <td>{{number_format( $buku->qty_stok, 0) }}</td>
                        <td>Rp{{number_format( $buku->harga, 0) }}</td>
                        <td>
                            <a class="text-center" href="{{ $buku->tautan }}" target="_blank">Lihat Tautan</a>
                            <!-- Tautan eksternal -->
                        </td>
                        <td>
                            <a href="{{ route('bukus.edit', $buku->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('bukus.destroy', $buku->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
