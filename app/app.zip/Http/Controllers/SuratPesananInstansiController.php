<?php

namespace App\Http\Controllers;

use App\Models\ItemPesananInstansi;
use App\Models\Kategori;
use App\Models\SuratPesananInstansi;
use App\Models\SuratPesananSekolah;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SuratPesananInstansiController extends Controller
{
    public function index(Request $request)
    {
        // Query untuk mengambil semua SuratPesananInstansi
        $query = SuratPesananInstansi::query();

        // Filter berdasarkan input pencarian, jika ada
        if ($request->has('search') && !empty($request->input('search'))) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('nama_data', 'like', "%{$search}%")
                    ->orWhere('nama_instansi', 'like', "%{$search}%")
                    ->orWhere('tanggal', 'like', "%{$search}%");
            });
        }

        // Mendapatkan semua data SuratPesananInstansi
        $suratPesananInstansis = $query->get();

        // Menghitung total profit dari SuratPesananInstansi
        $profitsSekolah = SuratPesananSekolah::sum('profit');

        // Mengambil jumlah profit dari SuratPesananInstansi
        $profitsInstansi = SuratPesananInstansi::sum('profit');

        // Menjumlahkan profits dari kedua model
        $profits = $profitsSekolah + $profitsInstansi;

        // Menghitung total item pesanan dari ItemPesananInstansi berdasarkan SuratPesananInstansi
        foreach ($suratPesananInstansis as $surat) {
            $surat->totalItem = $surat->itemPesananInstansi()->sum('total_per_object');
            $surat->sp = $surat->profit()->value('sp');
        }

        return view('surat_pesanan_instansi.index', compact('suratPesananInstansis', 'profits'));
    }

    public function create()
    {
        $profitsSekolah = SuratPesananSekolah::sum('profit');

        // Mengambil jumlah profit dari SuratPesananInstansi
        $profitsInstansi = SuratPesananInstansi::sum('profit');

        // Menjumlahkan profits dari kedua model
        $profits = $profitsSekolah + $profitsInstansi;
        $kategoris = Kategori::all();
        $sumdata = SuratPesananInstansi::whereNull('deleted_at')->count();

        return view('surat_pesanan_instansi.create', compact('kategoris', 'sumdata', 'profits'));
    }

    public function store(Request $request)
    {

        // dd($request->all());

        $request->validate(
            [
                'kategori_id' => 'required|exists:kategoris,id',
                'nomor' => 'required|string|max:255',
                'nama_data' => 'required|string|max:255|unique:surat_pesanan_instansis,nama_data',
                'tanggal' => 'required|date',
                'nama_instansi' => 'required|string|max:255',
                'npsn' => 'required|string|max:255',
                'npwp' => 'required|string|max:255',
                'alamat' => 'required|string',
                'kecamatan' => 'required|string|max:255',
                'kabupaten' => 'required|string|max:255',
                'telepon' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'nama_pemimpin_instansi' => 'required|string|max:255',
                'nip_pemimpin_instansi' => 'required|string|max:255',
                'nama_bendahara' => 'required|string|max:255',
                'nip_bendahara' => 'required|string|max:255',
                'nama_bank' => 'required|string|max:255',
                'rekening' => 'required|string|max:255',
                'nama_pemesan' => 'required|string|max:255',
                'nip_nama_pemesan' => 'required|string|max:255',
                'nama_penerima_pesanan' => 'required|string|max:255',
                'keterangan' => 'nullable|string',
            ],
            [
                'nama_data.unique' => 'Nama data ini sudah tersedia. Silakan pilih nama lain.',
            ]
        );

        $nomor = str_pad($request->input('nomor'), 5, '0', STR_PAD_LEFT);
        $tahun = date('Y');
        $formattedNomor = "{$nomor}/AAN - MLG/{$tahun}";

        SuratPesananInstansi::create([
            'kategori_id' => $request->input('kategori_id'),
            'nomor' => $formattedNomor,
            'nama_data' => $request->input('nama_data'),
            'tanggal' => $request->input('tanggal'),
            'nama_instansi' => $request->input('nama_instansi'),
            'npsn' => $request->input('npsn'),
            'npwp' => $request->input('npwp'),
            'alamat' => $request->input('alamat'),
            'kecamatan' => $request->input('kecamatan'),
            'kabupaten' => $request->input('kabupaten'),
            'telepon' => $request->input('telepon'),
            'email' => $request->input('email'),
            'nama_pemimpin_instansi' => $request->input('nama_pemimpin_instansi'),
            'nip_pemimpin_instansi' => $request->input('nip_pemimpin_instansi'),
            'nama_bendahara' => $request->input('nama_bendahara'),
            'nip_bendahara' => $request->input('nip_bendahara'),
            'nama_bank' => $request->input('nama_bank'),
            'rekening' => $request->input('rekening'),
            'nama_pemesan' => $request->input('nama_pemesan'),
            'nip_nama_pemesan' => $request->input('nip_nama_pemesan'),
            'nama_penerima_pesanan' => $request->input('nama_penerima_pesanan'),
            'keterangan' => $request->input('keterangan'),
        ]);

        return redirect()->route('surat_pesanan_instansi.index')->with('success', 'Surat Pesanan Instansi berhasil ditambahkan.');
    }

    public function edit(SuratPesananInstansi $suratPesananInstansi)
    {
        $profitsSekolah = SuratPesananSekolah::sum('profit');

        // Mengambil jumlah profit dari SuratPesananInstansi
        $profitsInstansi = SuratPesananInstansi::sum('profit');

        // Menjumlahkan profits dari kedua model
        $profits = $profitsSekolah + $profitsInstansi;
        $kategoris = Kategori::all(); // Fetch all categories to populate the dropdown
        $sumdata = SuratPesananInstansi::whereNull('deleted_at')->count();

        return view('surat_pesanan_instansi.edit', compact('suratPesananInstansi', 'kategoris', 'sumdata', 'profits'));
    }

    public function update(Request $request, SuratPesananInstansi $suratPesananInstansi)
    {
        $request->validate(
            [
                'kategori_id' => 'required|exists:kategoris,id',
                'nomor' => 'required|string|max:255',
                'nama_data' => 'required|string|max:255|unique:surat_pesanan_instansis,nama_data,' . $suratPesananInstansi->id,
                'tanggal' => 'required|date',
                'nama_instansi' => 'required|string|max:255',
                'npsn' => 'required|string|max:255',
                'npwp' => 'required|string|max:255',
                'alamat' => 'required|string',
                'kecamatan' => 'required|string|max:255',
                'kabupaten' => 'required|string|max:255',
                'telepon' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'nama_pemimpin_instansi' => 'required|string|max:255',
                'nip_pemimpin_instansi' => 'required|string|max:255',
                'nama_bendahara' => 'required|string|max:255',
                'nip_bendahara' => 'required|string|max:255',
                'nama_bank' => 'required|string|max:255',
                'rekening' => 'required|string|max:255',
                'nama_pemesan' => 'required|string|max:255',
                'nip_nama_pemesan' => 'required|string|max:255',
                'nama_penerima_pesanan' => 'required|string|max:255',
                'keterangan' => 'nullable|string',
                'profit' => 'nullable|numeric',
            ]
        );

        $suratPesananInstansi->update([
            'kategori_id' => $request->input('kategori_id'),
            'nomor' => $request->input('nomor'),
            'nama_data' => $request->input('nama_data'),
            'tanggal' => $request->input('tanggal'),
            'nama_instansi' => $request->input('nama_instansi'),
            'npsn' => $request->input('npsn'),
            'npwp' => $request->input('npwp'),
            'alamat' => $request->input('alamat'),
            'kecamatan' => $request->input('kecamatan'),
            'kabupaten' => $request->input('kabupaten'),
            'telepon' => $request->input('telepon'),
            'email' => $request->input('email'),
            'nama_pemimpin_instansi' => $request->input('nama_pemimpin_instansi'),
            'nip_pemimpin_instansi' => $request->input('nip_pemimpin_instansi'),
            'nama_bendahara' => $request->input('nama_bendahara'),
            'nip_bendahara' => $request->input('nip_bendahara'),
            'nama_bank' => $request->input('nama_bank'),
            'rekening' => $request->input('rekening'),
            'nama_pemesan' => $request->input('nama_pemesan'),
            'nip_nama_pemesan' => $request->input('nip_nama_pemesan'),
            'nama_penerima_pesanan' => $request->input('nama_penerima_pesanan'),
            'keterangan' => $request->input('keterangan'),
            'profit' => $request->input('profit'),
        ]);

        return redirect()->route('surat_pesanan_instansi.index')->with('success', 'Surat Pesanan Instansi berhasil diperbarui.');
    }

    public function destroy(SuratPesananInstansi $suratPesananInstansi)
    {
        $suratPesananInstansi->delete();

        return redirect()->route('surat_pesanan_instansi.index')->with('success', 'Surat Pesanan Instansi berhasil dihapus.');
    }
}
