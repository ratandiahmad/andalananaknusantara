<?php

namespace App\Http\Controllers;

use App\Models\PoItemPesanan;
use App\Http\Requests\StorePoItemPesananRequest;
use App\Http\Requests\UpdatePoItemPesananRequest;

class PoItemPesananController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePoItemPesananRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PoItemPesanan $poItemPesanan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PoItemPesanan $poItemPesanan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePoItemPesananRequest $request, PoItemPesanan $poItemPesanan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PoItemPesanan $poItemPesanan)
    {
        //
    }
}
